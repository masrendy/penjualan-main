# penjualan
Sistem informasi penjualan toko komputer berbasis web menggunakan PHP dan database MySql

==========Login==========
| Username : admin       |
| password : admin       |
=========================

Silahkan follow instagram saya @vignaditya

![Screenshot_129](https://user-images.githubusercontent.com/48781561/178160218-5026bed9-2ee6-4e29-b6db-a895d0fe53b6.png)
![Screenshot_128](https://user-images.githubusercontent.com/48781561/178160220-d44ab9ab-84bd-41c1-8c36-fd7fe420b548.png)
![Screenshot_127](https://user-images.githubusercontent.com/48781561/178160221-e1e52de1-1b5a-451b-a7e7-2437286e6b1b.png)
![Screenshot_126](https://user-images.githubusercontent.com/48781561/178160223-5d06b4c4-c807-4255-a85c-25685edc251d.png)
![Screenshot_131](https://user-images.githubusercontent.com/48781561/178160224-9049a5ab-d33a-4b31-833f-b5df3511a6f8.png)
![Screenshot_130](https://user-images.githubusercontent.com/48781561/178160226-0273a873-20c3-42c2-92be-a0e5283de833.png)
