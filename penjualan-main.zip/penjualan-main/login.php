<?php
require 'function.php';

if(isset($_SESSION['login'])){
    header('location:index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Login - ELEKTRONIK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://use.fontawesome.com/releases/v6.1.0/css/all.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #0f2027, #203a43, #2c5364); /* gradasi biru gelap */
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .card {
            background-color: #fff;
            border-radius: 1rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }

        .card-header {
            background-color: #001f3f; /* biru tua */
            color: #fff;
            border-top-left-radius: 1rem;
            border-top-right-radius: 1rem;
            text-align: center;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .form-control {
            border-radius: 0.5rem;
        }

        footer {
            position: absolute;
            bottom: 10px;
            width: 100%;
            color: #ccc;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow-lg">
                    <div class="card-header py-4">
                        <h3 class="mb-0">Login Sistem Elektronik</h3>
                    </div>
                    <div class="card-body px-4 py-4">
                        <form method="post">
                            <div class="form-floating mb-3">
                                <input type="text" name="username" class="form-control" id="inputUsername" placeholder="Username" required>
                                <label for="inputUsername"><i class="fas fa-user"></i> Username</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="password" name="password" class="form-control" id="inputPassword" placeholder="Password" required>
                                <label for="inputPassword"><i class="fas fa-lock"></i> Password</label>
                            </div>
                            <div class="d-grid">
                                <button type="submit" name="login" class="btn btn-primary py-2">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
                <footer class="mt-3">
                    <small>&copy; Rendy & Torik - 2025</small>
                </footer>
            </div>
        </div>
    </div>
</body>
</html>
